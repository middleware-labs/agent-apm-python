import setuptools

setuptools.setup(
    name="CheckUtil",
    version="0.0.1",
    author="Nidhi Sharma",
    description="This package is use to check the RAM and CPU Usage of Current Device.",
    packages=["CheckUtil"]
)